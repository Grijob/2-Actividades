package mx.grijob.a2actividades;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText etNombre, etFechaNacimiento, etTelefono, etEmail, etDescripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNombre = findViewById(R.id.etNombre);
        etFechaNacimiento = findViewById(R.id.etFechaNacimiento);
        etTelefono = findViewById(R.id.etTelefono);
        etEmail = findViewById(R.id.etEmail);
        etDescripcion = findViewById(R.id.etDescripcion);
        Button btnSiguiente = findViewById(R.id.btnSiguiente);

        etFechaNacimiento.setOnClickListener(v -> showDatePickerDialog());

        btnSiguiente.setOnClickListener(v -> {
            if (validarCampos()) {
                Intent intent = new Intent(MainActivity.this, Confirmacion.class);
                intent.putExtra("nombre", etNombre.getText().toString());
                intent.putExtra("fecha_nacimiento", etFechaNacimiento.getText().toString());
                intent.putExtra("telefono", etTelefono.getText().toString());
                intent.putExtra("email", etEmail.getText().toString());
                intent.putExtra("descripcion", etDescripcion.getText().toString());
                startActivity(intent);
            }
        });
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            String fecha = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
            etFechaNacimiento.setText(fecha);
        }, year, month, day);
        datePickerDialog.show();
    }

    private boolean validarCampos() {
        // Validar que todos los campos estén llenos
        if (etNombre.getText().toString().isEmpty() ||
                etFechaNacimiento.getText().toString().isEmpty() ||
                etTelefono.getText().toString().isEmpty() ||
                etEmail.getText().toString().isEmpty() ||
                etDescripcion.getText().toString().isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
