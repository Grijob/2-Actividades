package mx.grijob.a2actividades;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Confirmacion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmacion);

        TextView tvNombreCompleto = findViewById(R.id.tvNombreCompleto);
        TextView tvFechaNacimiento = findViewById(R.id.tvFechaNacimiento);
        TextView tvTelefono = findViewById(R.id.tvTelefono);
        TextView tvEmail = findViewById(R.id.tvEmail);
        TextView tvDescripcion = findViewById(R.id.tvDescripcion);
        Button btnEditarDatos = findViewById(R.id.btnEditarDatos);

        // Obtener datos de MainActivity
        String nombre = getIntent().getStringExtra("nombre");
        String fechaNacimiento = getIntent().getStringExtra("fecha_nacimiento");
        String telefono = getIntent().getStringExtra("telefono");
        String email = getIntent().getStringExtra("email");
        String descripcion = getIntent().getStringExtra("descripcion");

        // Mostrar datos en TextViews
        tvNombreCompleto.setText(nombre);
        tvFechaNacimiento.setText(fechaNacimiento);
        tvTelefono.setText(telefono);
        tvEmail.setText(email);
        tvDescripcion.setText(descripcion);

        btnEditarDatos.setOnClickListener(v -> {
            // Regresar a la MainActivity para editar
            finish();
        });
    }
}
